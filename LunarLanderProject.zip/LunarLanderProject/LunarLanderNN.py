import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import pickle
import matplotlib.pyplot as plt
import math
import csv


#########----------------------------Reading Processed CSV File -------------------------------------##############
Lander_Data = pd.read_csv('C:\\Assignment\\ce889_dataCollection.csv',header = None)


#Lander_Data = pd.read_csv('C:\\Assignment\\NewData.csv',header = None)
########---------------------------Normalization of Data (MIN-MAX Normalization)-------------############
Normalized_Data =  (Lander_Data - Lander_Data.min())/(Lander_Data.max() - Lander_Data.min())

########-----------------------Dividing Normalized Data into Input and Outpur------------################
X = Normalized_Data.iloc[:,0:2]
X = np.array(X)
Y = Normalized_Data.iloc[:,2:]
Y = np.array(Y)

########-------------------Spliting Data into Train, test and Validation Set--------------##############
X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.30, random_state = 42)
X_val, X_Ftest, Y_val, Y_Ftest = train_test_split(X_test,Y_test, test_size = 0.50, random_state = 42)


########------------------Creating Neural Network Class for Lunar Lander------------------##############
class NeuralNetworkLunarLander:
    
    def __init__(self):
        self.parameters = {}
        self.Lambda = 0.6
        self.epoch_error_list = []
        
    #####------------- Defining sizes for parameters-------------------########    
    def Sizes(self,X,Y):
        sizeX = X.shape[1]
        sizeY = Y.shape[1]
        sizeHid = 15
        return sizeX, sizeY, sizeHid
       
    #####--------------Definition of Sigmoid funtion-------------------########
    def sigmoidFunc(self,v):
        sigmoid_Res = (1 / (1 + np.exp(-self.Lambda*v)))
        return sigmoid_Res
    
    #####--------------Initializing Parameters with Random values------########
    def initializeParams(self,nx, ny, nh):
        np.random.seed(42)
        W1 = np.random.randn(nx,nh)           ##-------------------Hidden Layer Weights
        #print('W1 --->',W1, W1.shape)
        b1 = np.zeros((1,nh))                 ##-------------------Hidden Layer Biases
        #print('b1 --->',b1, b1.shape)
        W2 =  np.random.randn(nh,ny)          ##-------------------Output Layer Weights
        #print('W2 --->',W2, W2.shape)
        b2 = np.zeros((1,ny))                 ##-------------------Output Layer Biases
        #print('b2 --->',b2, b2.shape)
        prev_delta_hidden = np.zeros(shape = (nx,nh))
        prev_delta_out = np.zeros(shape=(nh,ny))
        bias_delta_hidden = np.zeros(shape = (1,nh))
        bias_delta_out = np.zeros(shape = (1,ny))
        self.parameters = {'W1':W1,'b1':b1,'W2':W2,'b2':b2,'P_D_O':prev_delta_out,'P_D_H':prev_delta_hidden,'B_D_O':bias_delta_out,'B_D_H':bias_delta_hidden}
        return self.parameters
    
    
    #####---------------Definition of Forward Propagation Funtion-------#######
    def forwardPropagation(self, X, Y_actual):
        Z1 = np.dot(X,self.parameters['W1']) + self.parameters['b1']  
        #print('Z1 --->',Z1, Z1.shape)
        H1 = self.sigmoidFunc(Z1)
        #print('H1 --->',H1, H1.shape)
        Z2 = np.dot(H1, self.parameters['W2']) + self.parameters['b2']
        #print('Z2 --->',Z2, Z2.shape)
        H2 = self.sigmoidFunc(Z2)
        #print('H2 --->',H2, H2.shape)
        err = (Y_actual - H2)
        weightCache = {'Z1':Z1, 'H1':H1, 'Z2':Z2, 'H2':H2, 'P_D_O':self.parameters['P_D_O'],'P_D_H':self.parameters['P_D_H'], 'B_D_O':self.parameters['B_D_O'], 'B_D_H':self.parameters['B_D_H']}
        return weightCache, err, H2
    
    
    #####---------------Definition of Backward Propagation Funtion-------#######
    def BackPropagation(self,Y_actual,X, cache, learningRate,alpha):
        Y_predicted = cache['H2']
        error = (Y_actual - Y_predicted)
        
        ##########--------------Calculating SLOPES for Output and Hidden Layers -------------------------################
        slope_out    = self.Lambda * Y_predicted * (1 - Y_predicted)
        #print('Slope at Output',slope_out,slope_out.shape)
        slope_hidden = self.Lambda * cache['H1'] * (1 - cache['H1'])
        #print('Slope at Hidden Layer',slope_hidden,slope_hidden.shape)
        
        ##########--------------Calculating change factor DELTA for Output and Hidden Layers ------------################
        delta_out    = error * slope_out
        #print('Change factor at Output',delta_out,delta_out.shape)
        
        error_hidden = np.dot(delta_out,self.parameters['W2'].T)
        delta_hidden = error_hidden * slope_hidden
        #print('Change factor at Hidden Layer',delta_hidden,delta_hidden.shape)
    
        
        #########---------------Calculating Updated weight amount for Output and Hidden Layers-----------################
        update_weight_out    =  learningRate * np.dot(cache['H1'].T,delta_out)
        #update_weight_out    =  np.dot( delta_out.T,cache['H1'])
        #print('Gradient Descent at output Layer',update_weight_out,update_weight_out.shape)
        
        update_weight_hidden = learningRate * np.dot(X.T, delta_hidden)
        #print('Gradient Descent at Hidden Layer',update_weight_hidden,update_weight_hidden.shape)
        
        ##############----------------Updating Weights and Biases for Output and Hidden Layers-----------################
        
        self.parameters['W2'] = self.parameters['W2'] + update_weight_out + alpha*self.parameters['P_D_O']
        previous_update_weight_out = update_weight_out
        self.parameters['b2'] = self.parameters['b2'] + (learningRate * np.sum(delta_out,axis = 0)) + alpha*self.parameters['B_D_O']
        previous_update_bias_out = learningRate * np.sum(delta_out,axis = 0)
        self.parameters['W1'] = self.parameters['W1'] +  update_weight_hidden + alpha * self.parameters['P_D_H']
        previous_update_weight_hidden = update_weight_hidden
        self.parameters['b1'] = self.parameters['b1'] + (learningRate * np.sum(delta_hidden, axis = 0)) + alpha*self.parameters['B_D_H']
        previous_update_bias_hidden = learningRate * np.sum(delta_hidden, axis = 0)
        #print('loss in epoch',np.average(residual))
        
        self.parameters = {'W1': self.parameters['W1'], 'b1': self.parameters['b1'], 'W2':self.parameters['W2'],'b2': self.parameters['b2'], 'P_D_O':previous_update_weight_out,'P_D_H':previous_update_weight_hidden,
                      'B_D_O':previous_update_bias_out,'B_D_H': previous_update_bias_hidden}
        return self.parameters, error
    
    
    
    ############----------------------Defining Training Function for Neural Network-------------------------###########
    def train(self,X_training,Y_training,X_validation, Y_validation, epochs,lr,alpha):
       
        nx,ny,nhid = self.Sizes(X_training,Y_training)
        #print(nx,ny,nhid)
        self.parameters = self.initializeParams(nx,ny,nhid)
        RMSE = []
        RMSE_Valid = []
        #RMSE_list_Valid = []
        for i in range(epochs):
            RMSE_list = []
            RMSE_list_Valid = []
            
            ##########----------------------------Forward and Backward Propagation on TrainingSet---------------#########
            for j in range(X_training.shape[0]):
                cache_past,err1, predict_train = self.forwardPropagation(X_training[j].reshape(1,2), Y_training[j].reshape(1,2))
                params, error = self.BackPropagation(Y_training[j].reshape(1,2),X_training[j].reshape(1,2), cache_past, lr,alpha)
                temp_error_i= np.sum(np.abs(error))/2
                RMSE_list.append(temp_error_i)
                
            ##########------------------------------Backward Propagation on ValidationSet------------------------#########
            for m in range(X_validation.shape[0]):
                cache_past_valid,err2, predict_validation = self.forwardPropagation(X_validation[m].reshape(1,2),Y_validation[m].reshape(1,2))
                #params, error = self.BackPropagation(Y_train[j].reshape(1,2),X_train[j].reshape(1,2), cache_past, 0.001,0.8)
                temp_error_i_valid= np.sum(np.abs(err2))/2
                RMSE_list_Valid.append(temp_error_i_valid)
            
            
            #########--------------------------------RMSE Calculation for Training Set --------------------------##########
            
            error_sum = sum([k**2 for k in RMSE_list])
            RMSE_epoch = math.sqrt(error_sum/X_training.shape[0])
            print('RMSE Value ----->',RMSE_epoch )
            RMSE.append(RMSE_epoch)
            
            #########------------------------------RMSE Calculation for Validation Set --------------------------##########
            
            error_sum_valid = sum([l**2 for l in RMSE_list_Valid])
            RMSE_epoch_valid = math.sqrt(error_sum_valid/X_validation.shape[0])
            print('RMSE Validation Value ------>',RMSE_epoch_valid )
            RMSE_Valid.append(RMSE_epoch_valid)
            
            
            
            ########-----------------------------Early Stopping Criteria----------------------------------------###########
            earlyStopCriteria = (abs(RMSE_epoch - RMSE_epoch_valid)/RMSE_epoch)*100
            if earlyStopCriteria < 0.00000001:
                break;    
            
            
        ###############------------------Plotting RMSE vs Epochs curve for Training and Validation Set----------############
        
        fig = plt.figure(figsize=(10,8))
        plt.plot(range(0,epochs),RMSE)
        plt.plot(range(0,epochs),RMSE_Valid)
        
        with open('Weight_Storage.csv','w') as f:
            weights = csv.DictWriter(f, self.parameters.keys())
            weights.writeheader()
            weights.writerow(self.parameters)
            
        
    ################-------------------------- Prediction on Testing Dataset-------------------------------################## 
       
    def Predict(self,X_testing,Y_testing):
        #predicted_val = self.forwardPropagation(X_testing,params, 0.5)
        RMSE_list_TEST = []
        for j in range(X_testing.shape[0]):
                cache_past,err3, predict_Test = self.forwardPropagation(X_testing[j].reshape(1,2), Y_testing[j].reshape(1,2))
                #params, error = self.BackPropagation(Y_train[j].reshape(1,2),X_train[j].reshape(1,2), cache_past, 0.05,0.9)
                temp_error_TEST = np.sum(np.abs(err3))/2
                RMSE_list_TEST.append(temp_error_TEST)
        error_sum_TEST = sum([l**2 for l in RMSE_list_TEST])
        temp_error_i_TEST = math.sqrt(error_sum_TEST/X_testing.shape[0])
        print("<=========RMSE ERROR for Testing===========>",temp_error_i_TEST)
        return temp_error_i_TEST
        
       
######---------------------------Creating Object for Neural Network Class-------------------------############################   
if __name__ =='__main__':
  ########----------------------------Creating Object For Neural Netowrk Class and training on datasets-------------##########
    NeuralNetwork  = NeuralNetworkLunarLander()
    #nx,ny,nh = NeuralNetwork.Sizes(X_train, Y_train)
    #parameters = NeuralNetwork.initializeParams(nx, ny, nh)
    NeuralNetwork.train(X_train,Y_train,X_val,Y_val,200,0.0185,0.9)
    NeuralNetwork.Predict(X_Ftest, Y_Ftest)
    
###########----------------------Creating Pickle Object for to store the values of Class object---------------################    
    with open("nn_obj.pickle", "wb") as f:
        pickle.dump(NeuralNetwork, f)
