import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
import pickle
from LunarLanderNN import NeuralNetworkLunarLander

class NeuralNetHolder:

    def __init__(self):
        super().__init__()
    
        with open("./nn_obj.pickle", "rb") as f:
            self.nn_obj = pickle.load(f)
        
        self.MAX = [799.274537,908, 8, 6.617275]
        self.MIN = [-810.722317,65.000151,-6.9,-7.486347]
         
    def normalized(self, x,minimum, maximum):
        normalizedData = (x - minimum)/(maximum - minimum)
        return normalizedData
    
    def denormalized(self, x_norm, maximum, minimum):
        denormalized_val = x_norm * (maximum - minimum) + minimum
        return denormalized_val
    
    
    def predict(self, input_row):
        ###---------
        lst = input_row.split(',')
        input_row = [float(i) for i in lst]
        ###--------------
        X1 = (self.normalized(input_row[0],self.MIN[0],self.MAX[0]))
        X2 = (self.normalized(input_row[1],self.MIN[1],self.MAX[1]))
        #x= self.normalized(input_rowm,)

        input_row = np.array([[X1,X2]])
        #print('input_row\n',input_row)
        #parameter = self.nn_obj.parameters
        Lambda = self.nn_obj.Lambda
        demoCache, error,prediction =  self.nn_obj.forwardPropagation(input_row,1)
        print('*****>',demoCache)
        print('Prediction\n',prediction)
        
        Y2 = self.denormalized(demoCache['H2'][0,1],self.MAX[3],self.MIN[3])
        Y1 = demoCache['H2'][0,0]
        return Y2,Y1
    
    
#NeuralNet  = NeuralNetHolder()
#NeuralNet.predict([45,56])