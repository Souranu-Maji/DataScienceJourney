#!/usr/bin/env python
# coding: utf-8

# # Group Project

# ### Libraries required

# In[4]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import datetime as dt
from sklearn import preprocessing
import sklearn
import seaborn as sns
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
from sklearn.linear_model import LinearRegression
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.express as px
sns.set_style("darkgrid")
import plotly.figure_factory as ff
from sklearn.neighbors import KNeighborsClassifier as knn
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow import keras


# ## Start of Pre-Processing

# In[5]:


train_data = pd.read_csv("train.csv", low_memory = False)
store_data = pd.read_csv("store.csv", low_memory = False)
test_data = pd.read_csv("test.csv", low_memory = False)


# In[6]:


def Percentage(df,colname,val):
    return round(df[df[colname]==val].shape[0]/df.shape[0] * 100,2)

def replaceWithZeros(df,col_name):
    df[col_name].fillna(0,inplace =True)
    return df

def findOutliers(df,col_name):
    Q1 = df[col_name].quantile(0.25)
    Q3 = df[col_name].quantile(0.75)
    IQR = Q3 - Q1
    high_cutoff = Q3 + 1.5*IQR
    low_cutoff = Q1 - 1.5*IQR
    return high_cutoff, low_cutoff

def LevelEncoding(df,col_name):
    labelEncoder = preprocessing.LabelEncoder()
    df[col_name] = labelEncoder.fit_transform(df[col_name])
    return df


# ### Pre-processing of training data

# In[7]:


print("Shape of Training Data",train_data.shape)
print('-----------------------------------')
print('Null Values thorughout the columns:')
train_data.isnull().sum()


# In[8]:


pOpen = Percentage(train_data,'Open',1)
print('Percentage of Open Stores in data:',str(pOpen) + ' %')
pClose = Percentage(train_data,'Open',0)
print('Percentage of Closed Stores in data:',str(pClose) + ' %')


# #### Remove samples in which store is closed and sales are zero

# In[9]:


print('Shape of Training before:',train_data.shape)
train_data = train_data[(train_data["Open"] != 0) & (train_data['Sales'] != 0)]
print('-----------------------------------------')
print('Shape of Training after:',train_data.shape)


# In[10]:


# QUESTION IN LINE 16 OF UNTITLED60 
# train_data = train_data.drop('Open', axis=1)


# #### Split dateTime to year, month and day

# In[11]:


train_data['Year'] = pd.DatetimeIndex(train_data['Date']).year
train_data['Month'] = pd.DatetimeIndex(train_data['Date']).month
train_data['Day'] = pd.DatetimeIndex(train_data['Date']).day


# #### Adding seasonality to dataBase

# In[12]:


train_data['Season'] = np.where(train_data['Month'].isin([3,4,5]), "Spring",
                 np.where(train_data['Month'].isin([6,7,8]), "Summer",
                 np.where(train_data['Month'].isin([9,10,11]), "Fall",
                 np.where(train_data['Month'].isin([12,1,2]), "Winter", "None"))))

print('New value of shape is:',train_data.shape)


# #### Find Outliers

# In[13]:


High, low = findOutliers(train_data,'Sales')
train_data_outlier = train_data[(train_data['Sales']< High) & (train_data['Sales']> low)]
print('New shape without outliers:',train_data_outlier.shape)


# ### Plot of features

# In[14]:


fig1 = px.line(train_data.groupby('Month')[['Sales']].mean())
fig2 = px.line(train_data.groupby('Day')[['Sales']].mean())
fig3 = px.line(train_data.groupby('DayOfWeek')[['Sales']].mean())
fig4 = px.line(train_data.groupby('Year')[['Sales']].mean())
fig5 = px.line(train_data.groupby('Season')[['Sales']].mean())

fig1.update_traces(mode='markers+lines',line_color = 'red')
fig1.show()
fig2.update_traces(mode='markers+lines',line_color = 'blue')
fig2.show()
fig3.update_traces(mode='markers+lines',line_color = 'green')
fig3.show()
fig4.update_traces(mode='markers+lines',line_color = 'orange')
fig4.show()
fig5.update_traces(mode='markers+lines',line_color = 'black')
fig5.show()


# ### Pre-processing of store data

# In[15]:


print("Shape of Store Data",store_data.shape)
print('------------------------------------')
cNDIS = store_data.isnull().sum()
print('Null Values thorughout the columns:')
print(cNDIS)


# In[16]:


print('Percentage of missing values for competition distance:')
print(round((cNDIS['CompetitionDistance']/store_data.shape[0]) * 100,2),'%')


# In[17]:


# Fill NaN Values in Competition Distance with mean()
store_data['CompetitionDistance'].fillna(store_data['CompetitionDistance'].mean(), inplace = True)


# In[18]:


NullPromo2StoreData = store_data[store_data['Promo2']==0]
print("Checking Null values when PROMO is absent =====>\n\n")
fig = px.bar(NullPromo2StoreData.isnull().sum())
fig.show()

WithPromo2StoreData = store_data[store_data['Promo2']==1]
print("Checking Null values when PROMO is present =====>\n\n")
fig = px.bar(WithPromo2StoreData.isnull().sum())
fig.show()


# #### Replacing NaN with zeros

# In[19]:


replaceWithZeros(store_data,'Promo2SinceWeek')
replaceWithZeros(store_data,'Promo2SinceYear')
replaceWithZeros(store_data,'PromoInterval')
replaceWithZeros(store_data,'CompetitionOpenSinceMonth')
replaceWithZeros(store_data,'CompetitionOpenSinceYear');


# ## Merging Store and Training DataSets

# In[20]:


mergedData = pd.merge(train_data, store_data, how='left', on='Store')
print('New Shape of Training Data:',mergedData.shape)


# #### Scatterplot

# In[21]:


plt.figure(figsize = (14,8))
fig1 = sns.scatterplot(x = mergedData['Customers'], y = mergedData['Sales'],hue = mergedData['StoreType'])


# #### Sales versus Day of Week for every StoreType

# In[22]:


fig = px.box(mergedData, x="DayOfWeek", y="Sales", color="StoreType")
fig.update_traces(quartilemethod="exclusive") # or "inclusive", or "linear" by default
fig.show()


# #### Sales versus StoreType

# In[23]:


fig = px.box(mergedData, x="StoreType", y="Sales",color = "StoreType")
fig.update_traces(quartilemethod="exclusive") # or "inclusive", or "linear" by default
fig.show()


# #### Trend of Sales over time

# In[19]:


fig5 = px.line(mergedData.groupby(['Date','StoreType']).mean()['Sales'].unstack())
fig5.show()


# ### Histogram of Sales vs StoreType 

# In[20]:


groupStoreType = list(mergedData['StoreType'].unique())
a = mergedData[mergedData['StoreType']=='a']['Sales']
b = mergedData[mergedData['StoreType']=='b']['Sales']
c = mergedData[mergedData['StoreType']=='c']['Sales']
d = mergedData[mergedData['StoreType']=='d']['Sales']

sns.distplot(mergedData[mergedData['StoreType']=='a']['Sales'])
sns.distplot(mergedData[mergedData['StoreType']=='b']['Sales'])
sns.distplot(mergedData[mergedData['StoreType']=='c']['Sales'])
sns.distplot(mergedData[mergedData['StoreType']=='d']['Sales'])


# ### Label Encoding

# In[21]:


mergedData = LevelEncoding(mergedData, 'StoreType')
mergedData = LevelEncoding(mergedData,'Assortment')
mergedData = LevelEncoding(mergedData, 'Season')
StateHolidayMaps = {'0':0,'a':1,'b':1,'c':1}
mergedData['StateHoliday'].replace(StateHolidayMaps, inplace = True)
PromoIntervalMaps = {'Jan,Apr,Jul,Oct':1, 'Feb,May,Aug,Nov':2, 'Mar,Jun,Sept,Dec':3}
mergedData['PromoInterval'].replace(PromoIntervalMaps, inplace = True)

corrmatrix = mergedData.corr()
top_corr_features = corrmatrix.index
plt.figure(figsize = (25,25))
g=sns.heatmap(mergedData[top_corr_features].corr(),annot=True,cmap="YlGnBu")


# #### Dropping columns that are highly correlated to Promo2

# In[22]:


mergedData = mergedData.drop('Promo2SinceWeek', axis=1)
mergedData = mergedData.drop('Promo2SinceYear', axis=1)
mergedData = mergedData.drop('PromoInterval', axis=1)


# #### Dropping one of the Competition Open Columns and Customers

# In[23]:


mergedData = mergedData.drop('CompetitionOpenSinceMonth', axis=1)
mergedData = mergedData.drop('Customers', axis=1)


# #### WRITE CSV

# In[24]:


mergedData.to_csv('CorrectDataTraining.csv')


# ### Implementing Wrapper method For Feature Extraction

# In[27]:


mergedData = mergedData.sample(frac=1).reset_index(drop=True)
mergedDataSample = mergedData.iloc[:100000,:]

ColumnNames = list(mergedDataSample.columns)
#PredictorColNames = ColumnNames['Sales']
Target = mergedDataSample['Sales']
ColumnNames.remove('Sales')
#PredictorColNames = ColumnNames
Predictor = mergedDataSample[ColumnNames]
#print(TargetColNames)
#print(ColumnNames)

PredictorSFS = Predictor
PredictorSFS = PredictorSFS.drop('Date', axis = 1)

sfs = SFS(knn(),
           k_features=8,
           forward=True,
           floating=True,
           scoring = 'accuracy',
           cv = 4,
         n_jobs=-1)

sfs.fit(PredictorSFS,Target);
SFS_outcome = pd.DataFrame(sfs.subsets_).transpose()

